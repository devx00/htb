"""Methods pertaining to machines on HTB.

This module contains classes and methods for working with machines
on HTB.
"""


from . import session
from .models import HTBObject
from typing import List, Optional
import json


class HTBMachine(HTBObject):
    """A machine on HTB
    
    Attributes:
        id (int): The machine ID.
        name (str): The name of the machine.
        os (str): The OS of the machine.
        active (bool): Whether the machine is active.
        retired (bool): Whether the machine is retired.
        difficulty (str): The machine difficulty (Easy, Medium Hard, Insane)
        points (int): The number of points the machine is worth.
        difficulty_chart (DifficultyChart): The difficulty chart data.
        solves (int): The number of solves the machine has.
        authUserSolve (bool): Whether the current user has solved this.
        authUserSolveTime (str): The time from release when the user solved it.
        likes (int): The number of likes this machine has.
        dislikes (int): The number of dislikes this machine has.
        description (str): The machine description.
        category_name (str): The category the machine is in.
        first_blood_user (str): The username of the blood user.
        first_blood_user_id (int): The id of the blood user.
        first_blood_time (str): The time since release it took to get blood.
        first_blood_user_avatar (str): The blood user's avatar image path.
        creator_id (int): The creator's user id.
        creator_name (str): The creator's username.
        creator_avatar (str): The creator's avatar image path.
        isRespected (bool): Whether the creator is respected by the curr user.
        download (bool): Whether this machine has files to download.
        sha256 (str): The sha256 checksum of the downloadable files.
        docker (bool): Whether this machine has a docker instance.
        docker_port (int): The port of the machines running docker instance.
        release_date (str): The date the machine was released.
        likeByAuthUser (bool): Whether the user liked the machine.
        dislikeByAuthUser (bool): Whether the user disliked the machine.
        isTodo (bool): Whether this machine is marked as todo.
        recommended (bool): Whether this machine is recommended.
    """
    
    objectendpoint = "/machine/profile/"
    objectkey = "info"

def findmachines(name: str) -> List[HTBMachine]:
    """Searches for machines matchine :name.

    Searches HTB for any machines matching the name :name.
    
    Args:
        name: A partial or full name to search for.
    Returns:
        A list of matching machines.
    """
    resp = session.get(
        "/search/fetch", 
        params={"query": name, "tags": json.dumps(["machines"])})
    results = resp.json()
    searchresults = results["machines"] if "machines" in results else []
    matches = [HTBMachine(res) for res in searchresults]
    return matches

def findmachine(name: str) -> Optional[HTBMachine]:
    """Finds a specific machine by name.

    Searches HTB for a specific machine matching the specified name
    and returns it if one is found. Otherwise returns None.

    Args:
        name: An exact box name to lookup.
    Returns:
        A HTBMachine matching the requested name.
    """
    boxes = findmachines(name)
    for box in boxes:
        if box.name == name:
            return box
